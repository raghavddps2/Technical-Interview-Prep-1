# `Rearrange Array Digits Problem`

1. First step was to write my own sorting function of merge sort, as taught in the lessons and with a very simple tweak, I wrote it for writing in descending order.

2. When I found the integers in a descending sorted manner, All i had to do is to combine integers alternately, beecause that would result in maximum integers. I verified that by running it on all integers from 0 to 9, and it gave appropriate results.

3. Time complexity: O(nlog(n))
4. Space complexity: O(n)
5. Data Structures Used: Recursion(Concept),Arrays