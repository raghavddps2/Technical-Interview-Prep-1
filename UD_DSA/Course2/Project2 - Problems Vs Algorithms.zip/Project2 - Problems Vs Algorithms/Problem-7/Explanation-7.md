# `HttpRouter using a Trie`

1. This is amost same as problem number 5, except for the edge cases, and working with a hierarchy of web pages instead of strings. 

2. Time complexity: O(N)
3. Space Complexity: O(N)

Here, in tries, it depends on the length of the path, we are searching on, and hence we get time complexity as O(N).

