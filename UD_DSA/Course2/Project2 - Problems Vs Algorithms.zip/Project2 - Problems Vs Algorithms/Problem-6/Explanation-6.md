# `Max and Min in an Unsorted Array`

1. We maintain two variables, maximum and minimum both of which are initialized to maximum negative and maximum positive value.

2. We then iterate over the entire array and update values as and when we find a greater and a smaller element.

3. Time complexity: O(n)
4. Space complexity: O(1)
5. Data Structure used: Arrays